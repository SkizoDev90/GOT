import { CaminanteBlanco } from "./CaminanteBlanco.js";
export class Dragon{
    #nombreDrag;
    #vida;
    #estate;
    #poder;
    #tipoAtaque;
    constructor(nombreDrag,poder,tipoAtaque){
        this.#nombreDrag=nombreDrag;
        this.#poder=poder;
        this.#tipoAtaque=tipoAtaque;
        this.#vida=100;
        this.#estate=true;
    }
    /*---------------------------GET-------------------------------- */
    getNombreDrag(){
        return this.#nombreDrag;
    }
    getPoder(){
        return this.#poder;
    }
    getTipoAtaque(){
        return this.#tipoAtaque;
    }
    getVida(){
        return this.#vida;
    }
    getEstate(){
        return this.#estate;
    }
    /*---------------------------SET-------------------------------- */
    setNombreDrag(valor){
        this.#nombreDrag=valor;
    }
    setPoder(valor){
        this.#poder=valor;
    }
    setTipoAtaque(valor){
        this.#tipoAtaque=valor;
    }
    getVida(){
        return this.#vida;
    }
    setVida(valor){
        this.#vida=valor;
    }
    setEstate(valor){
        this.#estate=valor;
    }
    /*---------------------------Funciones-------------------------------- */
    atacar(oponente){
        if(oponente instanceof CaminanteBlanco){
            oponente.setEstate(false);
        }else{
            oponente.setVida(oponente.getVida()-this.#poder);
        }
    }
    recibirDaño(puntos){
        this.#vida = this.#vida-puntos;
        /*Si llega ha cero llama a morirse y dentro se agrega a los muertos en batalla y retorna falso para eliminar del array de la casa*/
        if(this.#vida<=0){
            this.#vida = 0;
            this.morirse();
            return false;
        }else{
            /*sino retorna true y sigue para un nuevo duelo*/
            return true;
        }
    }
    morirse(){
        if(this.#estate == false){
            console.log("Los muertos no pueden morir");
        }else{
            this.#estate = false;
            console.log("");
            console.log(`-${this.#nombreDrag} ha muerto en combate`);
        }
    }
}