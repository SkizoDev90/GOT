import { Personaje } from "../Personaje.js";
import { Guerrero } from "./Guerrero.js";
import { Arma } from "../Arma.js";
export class CaminanteBlanco extends Personaje{
    #poderHelado;
    #vida;
    constructor(name,age,estate,house,poderHelado){
        super(name,age,estate,house);
        this.#poderHelado=poderHelado;
        this.#vida=100;
        this.setEstate(true);
    }
    /*---------------------------GET-------------------------------- */
    getPoderHelado(){
        return this.#poderHelado;
    }
    getVida(){
        return this.#vida
    }
    /*---------------------------SET-------------------------------- */
    setPoderHelado(valor){
        this.#poderHelado=valor;
    }
    setVida(valor){
        this.#vida=valor;
    }
    /*-------------------------FUNCIONES--------------------*/
    atacar(oponente){
        if(oponente instanceof Guerrero){
            oponente.setVida(oponente.getVida()-this.#poderHelado);
        }
        console.log(`${this.getName()} ataca al rival ${oponente.getName()} causandole ${this.#poderHelado} puntos`);
    }
    recibirDaño(puntos,arma){
        if(arma instanceof Arma && arma.getTypeArm()=="acero valyrio"){
            this.#vida = this.#vida-puntos;
        }else{
            console.log("O no es un Arma o no es de Acero Valirio")
        }
        /*Si llega ha cero llama a morirse y dentro se agrega a los muertos en batalla y retorna falso para eliminar del array de la casa*/
        if(this.#vida<=0){
            this.#vida = 0;
            this.morirse();
            return false;
        }else{
            /*sino retorna true y sigue para un nuevo duelo*/
            return true;
        }
    }
    morirse(){
        if(this.getEstate() == false){
            console.log("Los muertos no pueden morir");
        }else{
            this.setEstate(false);
            console.log("");
            console.log(`-${this.getName()} ha muerto en combate`);
        }
    }
}