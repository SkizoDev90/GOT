import { Personaje } from "../Personaje.js";
import { Consejero } from "./Consejero.js";

export class Khaleesi extends Personaje{
    #dragones=[];
    #consejero = new Consejero();
    constructor(name,age,estate,house,dragones,consejero){
        super(name,age,estate,house);
        this.#dragones=dragones;
        this.#consejero=consejero;
    }
     /*---------------------------GET-------------------------------- */
     getDragones(){
        return this.#dragones;
     }
     getConsejero(){
        return this.#consejero;
     }
      /*---------------------------SET-------------------------------- */
     setDragones(valor){
        this.#dragones.push(valor);
     }
     setConsejero(valor){
        if(valor instanceof Consejero){
            this.#consejero = valor;
        }else{
            console.log("No es tipo consejero");
        }
     }
}