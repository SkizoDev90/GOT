export class Arma{
    #nameArm;
    #damage;
    #typeArm;
    
    constructor(nameArm,damage,typeArm){
        this.#nameArm = nameArm;
        this.#damage = damage;
        this.#typeArm = typeArm;
    }
    /*---------------------------GET-------------------------------- */
    getNameArm(){
        return this.#nameArm;
    }
    getDamage(){
        return this.#damage;
    }
    getTypeArm(){
        return this.#typeArm;
    }
    /*---------------------------SET-------------------------------- */
    setNameArm(valor){
        this.#nameArm = valor;
    }
    setDamage(valor){
        this.#damage = valor;
    }
    setTypeArm(valor){
        this.#typeArm = valor;
    }

    /*----------------------------Funciones--------------------------- */
    explicarArma(){
        console.log (`${this.#nameArm} (${this.#typeArm}) - daño: ${this.#damage}`);
    }
}