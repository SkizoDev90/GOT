import { Guerrero } from "./presonajesEspeciales/Guerrero.js";
import { Khaleesi } from "./presonajesEspeciales/Khalesi.js";
import { CaminanteBlanco } from "./presonajesEspeciales/CaminanteBlanco.js";
export class Batalla{
    #muertes;
    constructor(){
        this.#muertes=[];
    }
    getMuertes(){
        return this.#muertes;
    }
    setMuertes(valor){
        this.#muertes.push(valor);
    }
    iniciarBatalla(casaS,casaL){
        /*mientras una casa tenga guerreros*/
        while(casaS.getMembers().length!=0 && casaL.getMembers().length!=0){
            /*Elijo un atacante aleatorio de entre las dos casas para que se puedan atacar todos a la vez*/
            const atacanteS = (Math.floor(Math.random()*casaS.getMembers().length));
            const atacanteL = (Math.floor(Math.random()*casaL.getMembers().length));
            console.log("__________________________________________________________________________________________");
            console.log(`${casaS.getMembers()[atacanteS].getName()} contra ${casaL.getMembers()[atacanteL].getName()}:`);
            /*Elijo quien ataca primero metiendolo en un array y haciendo otro random entre el array*/
            const opciones=[atacanteS,atacanteL];
            const atacaPrimero=opciones[Math.floor(Math.random()*opciones.length)];
            /*Guardo el guerrero en una variable lo he tenido que hacer por que me estaba haciendo un lio*/
            const guerreroS=casaS.getMembers()[atacanteS];
            const guerreroL=casaL.getMembers()[atacanteL];
            /*comparo para saber que casa ataca a cual primero para hacer el primer ataque aleatorio*/
            if (atacaPrimero==atacanteS){
                guerreroS.atacar(guerreroL);
                /*primer ataque*/
                if(!guerreroL.recibirDaño(guerreroS.getArm().getDamage())){
                    this.#muertes.push(guerreroL);
                    /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo de la casa*/
                    casaL.getMembers().splice(atacanteL,1);
                };
                /*Segundo ataque*/
                /*Si siguen con vida contraataca esto se lo puse por que no cai y cuando mataba al contrincante si lo quitaba del array le tocaba atacar aun muerto*/
                if(guerreroL.getVida()>0){
                    guerreroL.atacar(casaS.getMembers()[atacanteS]);
                    if(!guerreroS.recibirDaño(guerreroL.getArm().getDamage())){
                        this.#muertes.push(guerreroS);
                        /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo de la casa*/
                        casaS.getMembers().splice(atacanteS,1);
                    };
                }
            }else{
                /*primer ataque*/
                guerreroL.atacar(casaS.getMembers()[atacanteS]);
                if(!guerreroS.recibirDaño(guerreroL.getArm().getDamage())){
                    this.#muertes.push(guerreroS);
                    /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo de la casa*/
                    casaS.getMembers().splice(atacanteS,1);
                };
                /*Segundo ataque*/
                /*Si siguen con vida contraataca*/
                if(guerreroS.getVida()>0){
                    guerreroS.atacar(guerreroL);
                    if(!casaL.getMembers()[atacanteL].recibirDaño(guerreroS.getArm().getDamage())){
                        this.#muertes.push(guerreroL);
                        /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo de la casa*/
                        casaL.getMembers().splice(atacanteL,1);
                    };
                }
            }
            console.log("");
            console.log(`${guerreroS.getName()}:${guerreroS.getVida()} || ${guerreroL.getName()}:${guerreroL.getVida()}`);
            console.log("");
        }
        console.log("-Ganador de la guerra:");
        (casaS.getMembers().length==0)?console.log(`Esta guerra la gana ${casaL.getNameHouse()}`):console.log(`Esta guerra la gana ${casaS.getNameHouse()}`);
        console.log("");
    }
    mostrarGuerrerosMuertosEnBatalla(){
        this.#muertes.forEach(personaje => {
            console.log(`${personaje.getName()}`);
        });
    }
    batallaFinal(casaStark, khaleesi, ejercitoCaminantes){
        /*añadimos al array todos los guerreros y dragones*/
        let arrayJon=[];
        casaStark.getMembers().forEach(combatiente => {
            if(combatiente instanceof Guerrero){
                arrayJon.push(combatiente);
            }
        });
        if(khaleesi instanceof Khaleesi){
            khaleesi.getDragones().forEach(dragon => {
                arrayJon.push(dragon);
            });
        }
        /*una vez tengamos los dos array*/
        /*mientras una casa tenga guerreros*/
        let daño;
        let dañoHelado;
        while(arrayJon.length!=0 && ejercitoCaminantes.length!=0){
            /*Saco un caminante blanco y un guerrero de sus arrays de manera aleatoria el math floor es por que random me devulve decimal*/
            const atacanteJhon = (Math.floor(Math.random()*arrayJon.length));
            const atacanteCaminante = (Math.floor(Math.random()*ejercitoCaminantes.length));
            console.log("__________________________________________________________________________________________");
            console.log(`${arrayJon[atacanteJhon]} contra ${ejercitoCaminantes[atacanteCaminante]}:`);
            /*Elijo quien ataca primero metiendolo en un array y haciendo otro random entre el array*/
            const opciones=[atacanteJhon,atacanteCaminante];
            const atacaPrimero=opciones[Math.floor(Math.random()*opciones.length)];
            /*Guardo el guerrero en una variable lo he tenido que hacer por que me estaba haciendo un lio*/
            const guerreroJhon=arrayJon[atacanteJhon];
            const guerreroCamina=ejercitoCaminantes[atacanteCaminante];
            /*comparo para saber que casa ataca a cual primero para hacer el primer ataque aleatorio*/
            if (atacaPrimero==atacanteJhon){
                guerreroJhon.atacar(guerreroCamina);
                /*vemos si es guerrero o dragon*/
                if(guerreroJhon instanceof Guerrero){
                    daño = guerreroJhon.getArm().getDamage();
                }else{
                    daño = guerreroJhon.getPoder();
                }
                if(guerreroCamina instanceof CaminanteBlanco){
                    dañoHelado=guerreroCamina.getPoderHelado();
                }

                /*primer ataque*/
                if(!guerreroCamina.recibirDaño(daño)){
                    this.#muertes.push(guerreroCamina);
                    /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo del array*/
                    ejercitoCaminantes.splice(atacanteCaminante,1);
                };
                /*Segundo ataque*/
                /*Si siguen con vida contraataca esto se lo puse por que no cai y cuando mataba al contrincante si lo quitaba del array le tocaba atacar aun muerto*/
                if(guerreroCamina.getVida()>0){
                    guerreroCamina.atacar(guerreroJhon);
                    if(!guerreroJhon.recibirDaño(dañoHelado)){
                        this.#muertes.push(guerreroJhon);
                        /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo de la casa*/
                        arrayJon.splice(atacanteJhon,1);
                    };
                }
            }else{
                /*vemos si es guerrero o dragon*/
                if(guerreroJhon instanceof Guerrero){
                    daño = guerreroJhon.getArm().getDamage();
                }else{
                    daño = guerreroJhon.getPoder();
                }
                if(guerreroCamina instanceof CaminanteBlanco){
                    dañoHelado=guerreroCamina.getPoderHelado();
                }
                /*primer ataque*/
                guerreroCamina.atacar(guerreroJhon);
                if(!guerreroJhon.recibirDaño(dañoHelado)){
                    this.#muertes.push(guerreroJhon);
                    /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo de la casa*/
                    arrayJon.splice(atacanteJhon,1);
                };
                /*Segundo ataque*/
                /*Si siguen con vida contraataca*/
                if(guerreroJhon.getVida()>0){
                    guerreroJhon.atacar(guerreroCamina);
                    if(!guerreroCamina.recibirDaño(daño)){
                        this.#muertes.push(guerreroCamina);
                        /*Si ha retornado false quiere decir que el personaje a muerto y tenemos que quitarlo de la casa*/
                        ejercitoCaminantes.splice(atacanteCaminante,1);
                    };
                }
            }
        }
    }
}