import { Arma } from "./Clases/Arma.js";
import { Casa } from "./Clases/Casa.js";
import {Guerrero} from "./Clases/presonajesEspeciales/Guerrero.js";
import {Batalla} from "./Clases/Batalla.js";
import { Khaleesi } from "./Clases/presonajesEspeciales/Khalesi.js";
import { Consejero } from "./Clases/presonajesEspeciales/Consejero.js";
import { Dragon } from "./Clases/presonajesEspeciales/Dragon.js";
import { CaminanteBlanco } from "./Clases/presonajesEspeciales/CaminanteBlanco.js";
// --------------------------------------------------
// 1. Crear casas y armas
// --------------------------------------------------
const casaStark = new Casa("Stark", "El invierno se acerca");
const casaLannister = new Casa("Lannister","Un lanister siempre paga sus deudas")
const garra = new Arma("Garra", 50, "acero valyrio");
const hacha = new Arma("Hacha del Norte", 40, "hierro");

// --------------------------------------------------
// 2. Crear guerreros de la Casa Stark
// --------------------------------------------------
const jon = new Guerrero("Jon Snow", 25, true, casaStark, garra);
const tormund = new Guerrero("Tormund", 30, true, casaStark, hacha);
const edd = new Guerrero("Edd", 28, true, casaStark, hacha);
casaStark.asignarCasa(jon);
casaStark.asignarCasa(tormund);
casaStark.asignarCasa(edd);

// --------------------------------------------------
// 3. Crear a Khaleesi y sus dragones
// --------------------------------------------------
const Tyrion = new Consejero("Tyrion",45,"Lanister",casaLannister,"Dar consejos sabios");
const drogon = new Dragon("Drogon", 60, "fuego");
const viserion = new Dragon("Viserion", 55, "fuego");
const rhaegal = new Dragon("Rhaegal", 50, "fuego");
const khaleesi = new Khaleesi("Daenerys Targaryen", 29, true, "Casa Targaryen",[drogon, viserion, rhaegal],Tyrion);

// --------------------------------------------------
// 4. Crear ejército de Caminantes Blancos
// --------------------------------------------------
const caminante1 = new CaminanteBlanco("Caminante 1",150,true,null, 35);
const caminante2 = new CaminanteBlanco("Caminante 2",150,true,null,40);
const caminante3 = new CaminanteBlanco("Caminante 3",150,true,null,30);
const caminante4 = new CaminanteBlanco("Caminante 4",150,true,null,50);

const ejercitoCaminantes = [caminante1, caminante2, caminante3, caminante4];

// --------------------------------------------------
// 5. Función para iniciar la batalla final
// --------------------------------------------------
const batallaFinal = new Batalla();
batallaFinal.batallaFinal(casaStark, khaleesi, ejercitoCaminantes);
